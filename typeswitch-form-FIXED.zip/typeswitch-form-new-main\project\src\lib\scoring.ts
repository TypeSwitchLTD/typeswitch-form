// src/lib/scoring.ts
// SINGLE SOURCE OF TRUTH for the overall score.
// Used by the UI (ResultsReport, ShareCard via App re-export) AND by
// supabase.ts when saving — so the score in the database always matches
// the score the user saw on screen.

import { TypingMetrics } from '../types';

// Coerce any metric to a safe non-negative finite number
const safeNum = (v: unknown): number => {
  const n = typeof v === 'number' ? v : Number(v);
  return isFinite(n) && n > 0 ? n : 0;
};

const round1 = (n: number): number => Math.round(n * 10) / 10;

// Speed adjustment shared by the score and the breakdown so they always agree.
// Positive = bonus, negative = penalty.
const getSpeedAdjustment = (wpm: number): number => {
  if (wpm >= 70) return 5;
  if (wpm >= 60) return 2;
  if (wpm >= 45) return 0;
  if (wpm >= 30) return -3;
  if (wpm >= 20) return -5;
  return -8;
};

// SCORING ALGORITHM - Range 40-100
export const calculateOverallScore = (metrics: TypingMetrics, completionRate: number = 100): number => {
  const languageErrors = safeNum(metrics?.languageErrors);
  const punctuationErrors = safeNum(metrics?.punctuationErrors);
  const deletions = safeNum(metrics?.deletions);
  const wpm = safeNum(metrics?.wpm);
  const frustration = safeNum(metrics?.frustrationScore);
  const completion = Math.max(0, Math.min(100, safeNum(completionRate) || 100));

  let score = 100; // Start from 100

  // 1. LANGUAGE ERRORS (most critical) - up to -25
  score -= Math.min(25, languageErrors * 2.5);

  // 2. PUNCTUATION ERRORS - up to -10
  score -= Math.min(10, punctuationErrors * 0.8);

  // 3. DELETIONS (only above 15) - up to -8
  if (deletions > 15) {
    score -= Math.min(8, (deletions - 15) * 0.4);
  }

  // 4. COMPLETION - up to -10
  if (completion < 100) {
    score -= Math.min(10, (100 - completion) * 0.1);
  }

  // 5. SPEED (WPM) - bonus/penalty (-8 to +5)
  score += getSpeedAdjustment(wpm);

  // 6. TYPING FLOW (frustrationScore) - up to -5
  score -= Math.min(5, frustration * 0.5);

  // Floor: 40, Ceiling: 100
  return Math.max(40, Math.min(100, Math.round(score)));
};

// Calculate wasted time in seconds
export const calculateWastedTime = (metrics: TypingMetrics): number => {
  const deletionTime = safeNum(metrics?.deletions) * 0.3;
  const correctionTime = safeNum(metrics?.corrections) * 2;
  const languageErrorTime = safeNum(metrics?.languageErrors) * 3;

  return Math.round(deletionTime + correctionTime + languageErrorTime);
};

export interface ScoreBreakdownItem {
  category: string;
  penalty: number; // > 0 = deduction, < 0 = bonus
  reason: string;
}

// Score breakdown — uses the exact same formulas as calculateOverallScore,
// so "100 - deductions + bonus" always reconciles with the final score
// (before the 40-100 clamp and final rounding).
export const getScoreBreakdown = (metrics: TypingMetrics, completionRate: number = 100) => {
  const languageErrors = safeNum(metrics?.languageErrors);
  const punctuationErrors = safeNum(metrics?.punctuationErrors);
  const deletions = safeNum(metrics?.deletions);
  const wpm = safeNum(metrics?.wpm);
  const frustration = safeNum(metrics?.frustrationScore);
  const completion = Math.max(0, Math.min(100, safeNum(completionRate) || 100));

  const breakdown: ScoreBreakdownItem[] = [];

  if (languageErrors > 0) {
    breakdown.push({
      category: 'Language Errors',
      penalty: round1(Math.min(25, languageErrors * 2.5)),
      reason: `${languageErrors} wrong language characters`
    });
  }

  if (punctuationErrors > 0) {
    breakdown.push({
      category: 'Punctuation Errors',
      penalty: round1(Math.min(10, punctuationErrors * 0.8)),
      reason: `${punctuationErrors} punctuation mistakes`
    });
  }

  if (deletions > 15) {
    breakdown.push({
      category: 'Excessive Deletions',
      penalty: round1(Math.min(8, (deletions - 15) * 0.4)),
      reason: `${deletions} deletions made`
    });
  }

  if (completion < 100) {
    breakdown.push({
      category: 'Incomplete Text',
      penalty: round1(Math.min(10, (100 - completion) * 0.1)),
      reason: `Only ${completion.toFixed(0)}% completed`
    });
  }

  const speedAdjustment = getSpeedAdjustment(wpm);
  if (speedAdjustment < 0) {
    breakdown.push({
      category: 'Typing Speed',
      penalty: -speedAdjustment,
      reason: `${wpm} WPM (below average)`
    });
  } else if (speedAdjustment > 0) {
    breakdown.push({
      category: 'Speed Bonus',
      penalty: -speedAdjustment, // negative penalty = bonus
      reason: `${wpm} WPM (above average)`
    });
  }

  if (frustration > 0) {
    breakdown.push({
      category: 'Flow Disruption',
      penalty: round1(Math.min(5, frustration * 0.5)),
      reason: `${frustration}/10 flow score`
    });
  }

  const totalPenalty = round1(breakdown.filter(i => i.penalty > 0).reduce((sum, i) => sum + i.penalty, 0));
  const totalBonus = round1(breakdown.filter(i => i.penalty < 0).reduce((sum, i) => sum - i.penalty, 0));
  return { breakdown, totalPenalty, totalBonus };
};
